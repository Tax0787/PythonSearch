pip install -U pip
pip install pyinstaller
pip install -U pyinstaller
pyinstaller -F -i=python.ico --add-data="python.ico;." ���̽�_�˻�.pyw
